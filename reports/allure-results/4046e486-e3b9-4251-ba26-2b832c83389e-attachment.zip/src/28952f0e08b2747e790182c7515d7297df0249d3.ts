import type { Locator, Page } from '@playwright/test';

export class ProductPage {
  private readonly page: Page;
  private readonly searchInput: Locator;
  private readonly searchButton: Locator;
  private readonly productsHeading: Locator;
  private readonly searchedProductsHeading: Locator;
  private readonly productCards: Locator;
  private readonly cartModal: Locator;
  private readonly viewCartLink: Locator;

  constructor(page: Page) {
    this.page = page;
    this.searchInput = page.getByPlaceholder('Search Product');
    this.searchButton = page.getByTestId('submit_search');
    this.productsHeading = page.getByRole('heading', {
      name: 'All Products',
      exact: true,
    });
    this.searchedProductsHeading = page.getByRole('heading', {
      name: 'Searched Products',
      exact: true,
    });
    this.productCards = page.locator('.product-image-wrapper');
    this.cartModal = page.locator('#cartModal');
    this.viewCartLink = this.cartModal.getByRole('link', {
      name: 'View Cart',
      exact: true,
    });
  }

  async waitUntilVisible(): Promise<void> {
    await this.productsHeading.waitFor({ state: 'visible' });
  }

  async searchFor(term: string): Promise<void> {
    await this.searchInput.fill(term);
    await this.searchButton.click();
    await this.searchedProductsHeading.waitFor({ state: 'visible' });
  }

  get searchedHeading(): Locator {
    return this.searchedProductsHeading;
  }

  async getVisibleProductNames(): Promise<string[]> {
    return this.page
      .locator('.product-image-wrapper .productinfo p')
      .allTextContents();
  }

  private productCard(productName: string): Locator {
    return this.productCards.filter({
      has: this.page.getByText(productName, { exact: true }),
    });
  }

  async addToCart(productName: string): Promise<void> {
    const card = this.productCard(productName).first();
    await card
      .locator('.productinfo')
      .getByRole('link', { name: 'Add to cart', exact: true })
      .click();
    await this.viewCartLink.waitFor({ state: 'visible' });
  }

  async openCartFromConfirmation(): Promise<void> {
    await this.viewCartLink.click();
  }

  async openProductDetails(productName: string): Promise<void> {
    const card = this.productCard(productName).first();
    await card
      .getByRole('link', { name: 'View Product', exact: true })
      .click();
  }
}