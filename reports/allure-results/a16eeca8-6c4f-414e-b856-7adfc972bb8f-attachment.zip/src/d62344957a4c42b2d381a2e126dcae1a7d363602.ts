import type { Locator, Page } from '@playwright/test';
import { NavigationComponent } from './NavigationComponent';

export class HeaderComponent {
  private readonly siteBrandLink: Locator;
  private readonly navigation: NavigationComponent;

  constructor(page: Page) {
    const header = page.getByRole('banner');
    this.siteBrandLink = header.getByRole('link', {
      name: 'Website for practice automation',
    });
    this.navigation = new NavigationComponent(page);
  }

  async waitUntilVisible(): Promise<void> {
    await this.siteBrandLink.waitFor({ state: 'visible' });
  }

  async openTestCases(): Promise<void> {
    await this.navigation.openTestCases();
  }
}