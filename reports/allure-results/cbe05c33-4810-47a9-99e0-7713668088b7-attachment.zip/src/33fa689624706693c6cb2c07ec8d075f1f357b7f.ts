import { expect, test } from '../../fixtures/uiTest';
import { ContactPage } from '../../pages/ContactPage';
import { HomePage } from '../../pages/HomePage';
import contactData from '../../test-data/contact.json';

test('Test Case 6: submit the Contact Us form', async ({ page }) => {
  page.on('request', (request) => {
    if (request.url().includes('contact_us')) {
      console.log(`Contact request ${request.method()} ${request.url()}`);
    }
  });
  page.on('response', (response) => {
    if (response.url().includes('contact_us')) {
      console.log(`Contact response ${response.status()} ${response.request().method()} ${response.url()}`);
    }
  });
  // Arrange
  const homePage = new HomePage(page);
  const contactPage = new ContactPage(page);
  const formData = contactData.form;
  const upload = contactData.upload;

  // Act
  await homePage.open();
  await homePage.waitUntilVisible();
  await homePage.openContactUs();
  await contactPage.waitUntilVisible();
  await contactPage.fillForm(formData);
  await contactPage.attachFile(
    upload.fileName,
    upload.mimeType,
    Buffer.from(upload.content),
  );
  const submissionResponse = page.waitForResponse(
    (response) =>
      response.url().endsWith('/contact_us') &&
      response.request().method() === 'POST',
  );

  // Assert the accepted POST and transient success message.
  const [response] = await Promise.all([
    submissionResponse,
    expect(contactPage.submissionSuccess).toHaveText(
      contactData.expectedSuccess,
    ),
    contactPage.submitAndAcceptConfirmation(),
  ]);
  expect(response.status()).toBe(200);
});