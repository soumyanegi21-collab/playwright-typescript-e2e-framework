import { expect, test } from '../../fixtures/uiTest';
import { CartPage } from '../../pages/CartPage';
import { HomePage } from '../../pages/HomePage';
import { ProductPage } from '../../pages/ProductPage';
import { ProductDetailsPage } from '../../pages/ProductDetailsPage';
import productsData from '../../test-data/products.json';

test('Test Cases 13 and 17: set cart quantity and remove the product', async ({
  page,
}) => {
  // Arrange
  const homePage = new HomePage(page);
  const productPage = new ProductPage(page);
  const productDetailsPage = new ProductDetailsPage(page);
  const cartPage = new CartPage(page);
  const productName = productsData.cartProduct.name;
  const quantity = productsData.cartProduct.quantity;

  page.on('request', (request) => {
    if (/cart|product/i.test(request.url())) {
      console.log(`${request.method()} ${request.url()}`);
    }
  });

  // Act
  await homePage.open();
  await homePage.waitUntilVisible();
  await homePage.openProducts();
  await productPage.waitUntilVisible();
  await productPage.openProductDetails(productName);
  await productDetailsPage.waitUntilVisible();
  await productDetailsPage.addToCart(quantity);
  await productDetailsPage.openCart();
  await cartPage.waitUntilVisible();

  // Assert product was added, then remove the same product.
  await expect(cartPage.productRow(productName)).toBeVisible();
  await expect(
    cartPage.productRow(productName).getByRole('button', {
      name: String(quantity),
      exact: true,
    }),
  ).toBeVisible();
  await cartPage.removeProduct(productName);
  await expect(cartPage.productRow(productName)).toHaveCount(0);
});