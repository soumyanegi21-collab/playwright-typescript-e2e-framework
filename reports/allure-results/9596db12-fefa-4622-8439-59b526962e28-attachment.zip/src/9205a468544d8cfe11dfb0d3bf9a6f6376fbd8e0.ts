import type { Locator, Page } from '@playwright/test';

export class ProductDetailsPage {
  private readonly page: Page;
  private readonly productHeading: Locator;
  private readonly quantityInput: Locator;
  private readonly addToCartButton: Locator;
  private readonly cartModal: Locator;
  private readonly viewCartLink: Locator;

  constructor(page: Page) {
    this.page = page;
    this.productHeading = page.getByRole('heading', {
      name: 'Blue Top',
      exact: true,
    });
    this.quantityInput = page.getByRole('spinbutton');
    this.addToCartButton = page.getByRole('button', {
      name: /Add to cart$/,
    });
    this.cartModal = page.locator('#cartModal');
    this.viewCartLink = this.cartModal.getByRole('link', {
      name: /View Cart$/,
    });
  }

  async waitUntilVisible(): Promise<void> {
    await this.productHeading.waitFor({ state: 'visible' });
  }

  async addToCart(quantity: number): Promise<void> {
    await this.quantityInput.fill(String(quantity));
    await this.addToCartButton.click();
    await this.viewCartLink.waitFor({ state: 'visible' });
  }

  async openCart(): Promise<void> {
    await this.viewCartLink.click();
  }
}