import type { Page } from '@playwright/test';
import { BasePage } from './BasePage';
import { HeaderComponent } from '../components/HeaderComponent';
import { URLS } from '../constants/application';

export class HomePage extends BasePage {
  private readonly header: HeaderComponent;

  constructor(page: Page) {
    super(page);
    this.header = new HeaderComponent(page);
  }

  async open(): Promise<void> {
    await this.navigateTo(URLS.home);
  }

  async waitUntilVisible(): Promise<void> {
    await this.header.waitUntilVisible();
  }

  async openTestCases(): Promise<void> {
    await this.header.openTestCases();
  }
}