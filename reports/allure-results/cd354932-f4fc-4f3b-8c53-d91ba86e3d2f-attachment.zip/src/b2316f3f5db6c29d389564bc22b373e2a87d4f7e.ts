import { expect, test } from '../../fixtures/uiTest';
import { CartPage } from '../../pages/CartPage';
import { HomePage } from '../../pages/HomePage';
import { ProductPage } from '../../pages/ProductPage';
import productsData from '../../test-data/products.json';

test('Test Cases 12 and 17: add and remove a product from the cart', async ({
  page,
}) => {
  // Arrange
  const homePage = new HomePage(page);
  const productPage = new ProductPage(page);
  const cartPage = new CartPage(page);
  const productName = productsData.cartProduct.name;

  // Act
  await homePage.open();
  await homePage.waitUntilVisible();
  await homePage.openProducts();
  await productPage.waitUntilVisible();
  await productPage.addToCart(productName);
  await cartPage.open();
  await cartPage.waitUntilVisible();

  // Assert product was added, then remove the same product.
  await expect(cartPage.productRow(productName)).toBeVisible();
  await cartPage.removeProduct(productName);
  await expect(cartPage.productRow(productName)).toHaveCount(0);
});