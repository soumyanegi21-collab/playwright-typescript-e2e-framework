import { expect, test as base } from '@playwright/test';

export const test = base.extend({
  page: async ({ page }, use) => {
    await page.route(
      /googlesyndication\.com|doubleclick\.net|googleadservices\.com|google\.com\/ads|googletagservices\.com/i,
      (route) => route.abort(),
    );
    await use(page);
  },
});

export { expect };