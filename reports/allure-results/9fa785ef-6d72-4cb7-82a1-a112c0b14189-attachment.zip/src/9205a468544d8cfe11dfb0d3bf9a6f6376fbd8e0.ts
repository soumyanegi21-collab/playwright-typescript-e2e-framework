import type { Locator, Page } from '@playwright/test';

export class ProductDetailsPage {
  private readonly page: Page;
  private readonly productHeading: Locator;
  private readonly quantityInput: Locator;
  private readonly addToCartButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.productHeading = page.getByRole('heading', {
      name: 'Blue Top',
      exact: true,
    });
    this.quantityInput = page.getByRole('spinbutton');
    this.addToCartButton = page.getByRole('button', {
      name: /Add to cart$/,
    });
  }

  async waitUntilVisible(): Promise<void> {
    await this.productHeading.waitFor({ state: 'visible' });
  }

  async addToCart(quantity: number): Promise<void> {
    await this.quantityInput.fill(String(quantity));
    await this.addToCartButton.click();
  }

  async openCart(): Promise<void> {
    await this.page.goto('/view_cart');
  }
}