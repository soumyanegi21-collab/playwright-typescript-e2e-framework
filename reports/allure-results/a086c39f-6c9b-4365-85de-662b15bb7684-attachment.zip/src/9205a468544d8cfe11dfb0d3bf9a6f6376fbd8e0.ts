import type { Locator, Page } from '@playwright/test';

export class ProductDetailsPage {
  private readonly page: Page;
  private readonly productHeading: Locator;
  private readonly quantityInput: Locator;
  private readonly addToCartButton: Locator;
  private readonly availability: Locator;
  private readonly condition: Locator;
  private readonly brand: Locator;

  constructor(page: Page) {
    this.page = page;
    this.productHeading = page.getByRole('heading', {
      name: 'Blue Top',
      exact: true,
    });
    this.quantityInput = page.getByRole('spinbutton');
    this.addToCartButton = page.getByRole('button', {
      name: /Add to cart$/,
    });
    this.availability = page.getByText('Availability: In Stock', {
      exact: true,
    });
    this.condition = page.getByText('Condition: New', { exact: true });
    this.brand = page.getByRole('link', { name: 'Polo', exact: true });
  }

  async waitUntilVisible(): Promise<void> {
    await this.productHeading.waitFor({ state: 'visible' });
  }

  async setQuantity(quantity: number): Promise<void> {
    await this.quantityInput.fill(String(quantity));
  }

  get quantity(): Locator {
    return this.quantityInput;
  }

  get addToCart(): Locator {
    return this.addToCartButton;
  }

  get productAvailability(): Locator {
    return this.availability;
  }

  get productCondition(): Locator {
    return this.condition;
  }

  get productBrand(): Locator {
    return this.brand;
  }
}